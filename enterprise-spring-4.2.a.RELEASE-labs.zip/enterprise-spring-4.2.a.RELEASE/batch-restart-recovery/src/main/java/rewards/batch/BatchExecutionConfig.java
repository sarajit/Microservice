package rewards.batch;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.context.annotation.Configuration;

// TODO 16 (BONUS): Add @EnableBatchProcessing to configure the Spring Batch infrastructure
@Configuration
public class BatchExecutionConfig {

}
