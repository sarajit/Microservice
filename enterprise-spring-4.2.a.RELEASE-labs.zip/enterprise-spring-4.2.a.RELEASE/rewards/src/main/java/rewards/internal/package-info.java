/**
 * The implementation of the rewards application.
 */
package rewards.internal;
