/**
 * The Restaurant module.
 */
package rewards.internal.restaurant;
